const dotenv = require("dotenv");
dotenv.config();
const { Client } = require("discord.js");
const fetch = require("node-fetch");

const client = new Client();

let isDeliActivated = false;

client.on("ready", () => {
  console.log("Discord'a bağlandı!");
});

client.on("message", async (message) => {
  if (!message.author.bot && message.content.startsWith(process.env.PREFIX)) {
    const [COMMAND_NAME, ...args] = message.content
      .trim()
      .substring(process.env.PREFIX.length)
      .split(/\s+/);

    if (COMMAND_NAME === "euro") {
      try {
        const response = await fetch(
          `https://v6.exchangerate-api.com/v6/${process.env.EXCHANGE_RATE_API_KEY}/latest/EUR`
        );
        const data = await response.json();
        const eurToTry = data.conversion_rates.TRY;
        message.channel.send(
          `1 Euro şu anda ${eurToTry} Türk Lirası ediyor.`
        );
      } catch (error) {
        console.error(error);
        message.channel.send("Euro kuru alınırken bir hata oluştu.");
      }
    }

    // Diğer komutlar burada
    else if (COMMAND_NAME === "oyunbaşlasın") {
      message.channel.send(
        "rololuştur komutunu kullanarak istediğiniz rolleri,\n' rol:kişi ' sayısı olarak aralarda boşluk bırakarak belirtiniz."
      );
    } else if (COMMAND_NAME === "rololuştur") {
      const voiceChannel = message.member.voice.channel;

      if (!voiceChannel) {
        return message.channel.send("Lütfen önce bir ses kanalına katılın.");
      }

      const members = voiceChannel.members.array();

      if (checkMaxValue(args) > members.length - 1) {
        return message.channel.send(
          "Girilen sayılarla toplam kişi sayısı eşleşmesinde hata meydana geldi... Lütfen gözden geçirdikten sonra tekrar deneyiniz."
        );
      }

      const selectedUsers = new Set();
      const userData = [];
      const adminRole = message.guild.roles.cache.find(
        (role) => role.name === "Yönetici"
      );

      const priorityAdminIds = [
        "986179225142837302",
        "404650598974357506",
        "806471992647352340",
      ];
      const priorityAdmins = members.filter((member) =>
        priorityAdminIds.includes(member.user.id)
      );
      let newAdmin = null;

      if (priorityAdmins.length > 0) {
        const randomAdminIndex = Math.floor(
          Math.random() * priorityAdmins.length
        );
        newAdmin = priorityAdmins[randomAdminIndex];
      } else {
        const randomAdminIndex = Math.floor(Math.random() * members.length);
        newAdmin = members[randomAdminIndex];
      }

      await newAdmin.send("Oyun Yöneticisi sensin, oyunu yönet!");

      let deliUser = null;
      if (isDeliActivated) {
        let randomUserIndex;
        let randomUser;

        do {
          randomUserIndex = Math.floor(Math.random() * members.length);
          randomUser = members[randomUserIndex];
        } while (
          selectedUsers.has(randomUser.user.id) ||
          randomUser.user.id === newAdmin.user.id
        );

        deliUser = randomUser;
        selectedUsers.add(deliUser.user.id);

        const deliRoles = ["doktor", "gözcü", "jester", "şerif", "kâhin"];
        const randomRole =
          deliRoles[Math.floor(Math.random() * deliRoles.length)];

        userData.push(
          `${deliUser.displayName} : ${randomRole.toUpperCase()} (Deli)`
        );
        deliUser
          .send(`Karakterin belli oldu! ${randomRole.toUpperCase()} oldun...`)
          .catch(console.error);
      }

      for (const arg of args) {
        const [key, value] = arg.split(":");

        for (let j = 0; j < parseInt(value); j++) {
          let randomUserIndex;
          let randomUser;

          do {
            randomUserIndex = Math.floor(Math.random() * members.length);
            randomUser = members[randomUserIndex];
          } while (
            selectedUsers.has(randomUser.user.id) ||
            randomUser.user.id === newAdmin.user.id ||
            (deliUser && randomUser.user.id === deliUser.user.id)
          );

          selectedUsers.add(randomUser.user.id);
          userData.push(`${randomUser.displayName} : ${key.toUpperCase()}`);

          randomUser
            .send(`Karakterin belli oldu! ${key.toUpperCase()} oldun...`)
            .catch(console.error);
        }
      }

      for (const member of members) {
        if (
          !selectedUsers.has(member.user.id) &&
          member.user.id !== newAdmin.user.id
        ) {
          userData.push(`${member.displayName} : KÖYLÜ`);
          member
            .send("Karakterin belli oldu! KÖYLÜSÜN...")
            .catch(console.error);
        }
      }

      let countdown = 5;
      message.channel.send("Oyunun başlamasına son...");
      const interval = setInterval(() => {
        message.channel.send(countdown);
        countdown--;
        if (countdown === 0) {
          message.channel.send("İyi eğlenceler Kantei üyeleri :)");
          clearInterval(interval);

          newAdmin.send("Oyundaki karakter listesi:").catch(console.error);
          for (const data of userData) {
            newAdmin.send(data).catch(console.error);
          }
        }
      }, 1000);
    } else if (COMMAND_NAME === "deliaç") {
      isDeliActivated = true;
      message.channel.send("Deli rolü aktif edildi.");
    } else if (COMMAND_NAME === "delikapat") {
      isDeliActivated = false;
      message.channel.send("Deli rolü devre dışı bırakıldı.");
    } else if (COMMAND_NAME === "rolbilgi") {
      const roleInfo = `
        **Vampir:** Akşam olduğunda öldüreceği kişiyi seçerler.

        **Köylü:** Sabah olduğunda olaylarla ilgili konuşurlar ve oy verebilirler.

        **Doktor:** Akşam iyileştirmek istediği birine gider eğer iyileştirmeye gittiği kişi Vampir saldırısına uğradıysa ölmez doktor tarafından iyileştirilir.

        **Gözcü:** Akşam istediği kişinin evine gider ve o eve kimin geldiğini görebilir.

        **Şerif:** Köylüler tarafından asılacakken veya Akşam hariç istediği kişiyi silahını çıkartıp vurabilir.

        **Deli:** Hayat ona güzeldir :D hiçbir şeyden haberi yoktur, ne olup ne bittiğini bilemez Masumdur.

        **Kâhin:** Akşam istediği 1 kişinin rolünü görebilir.

        **Kumarbaz:** Sabah köylüler tarafından asılacakken veya Akşam hariç istediği zaman kendinin kumarbaz olduğunu söyleyebilir söylediği zaman 2 şansı vardır ya ölür yada kazanır Oyun Yöneticisi 7 ilâ 1 arasında bir sayı tutar, Eğer kumarbaz sayıyı bilirse oyunu kazanır bilemezse ölür.

        **Jester:** Eğer kendini köy halkı tarafından astırabilirse kazanabilir ama eğer Vampirler tarafından öldürülürse kazanamaz. (Dikkat edin bu herife)

        **Susturucu:** Her akşam istediği kişiyi 1 Sabah susturabilir, susturduğu kişi konuşamaz.
            `;

      message.channel.send(roleInfo);
    } else if (COMMAND_NAME === "dolar") {
      try {
        const response = await fetch(
          `https://v6.exchangerate-api.com/v6/${process.env.EXCHANGE_RATE_API_KEY}/latest/USD`
        );
        const data = await response.json();
        const usdToTry = data.conversion_rates.TRY;
        message.channel.send(
          `1 Amerikan Doları şu anda ${usdToTry} Türk Lirası ediyor.`
        );
      } catch (error) {
        console.error(error);
        message.channel.send("Dolar kuru alınırken bir hata oluştu.");
      }
    }
  }
});

function checkMaxValue(args) {
  let max = 0;
  for (const arg of args) {
    const [key, value] = arg.split(":");
    if (key !== "yonetici") {
      max += parseInt(value);
    }
  }
  return max;
}

client.login(process.env.DISCORD_TOKEN).catch(console.error);
